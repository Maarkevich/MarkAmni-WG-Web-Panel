import { NextRequest, NextResponse } from 'next/server';
import { bootstrap } from '@/lib/awg/bootstrap';
import { guard, isGuardFail, err } from '@/lib/awg/api';
import * as store from '@/lib/awg/store';
import * as conf from '@/lib/awg/conf';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  await bootstrap();
  const g = guard(req, 'clients');
  if (isGuardFail(g)) return g;
  const { id } = await params;
  const db = store.get();
  const c = db.clients.find((x) => x.id === id);
  if (!c) return err('Клиент не найден', 404);
  const text = conf.buildClientConf(db, c);
  return new NextResponse(text, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Content-Disposition': `attachment; filename="${encodeURIComponent(c.name)}.conf"`
    }
  });
}
